if (typeof jQuery === 'undefined') {
  throw new Error('Bootstrap\'s JavaScript requires jQuery')
}
/********************************************************/
//AUTHOR: Manu Dávila
//Blog: http://jquery-manual.blogspot.com
/***********************A Q U I  E M P E Z A M O S  L O  D E  E L  J Q U E R Y*****************************/
$(function () {

	var cargando = $("#ajax-loading");  // para el efecto del ajax
	var getUrl = window.location;
	var baseUrlCorta = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
	var baseUrlCortaCorta = getUrl .protocol + "//" + getUrl.host + "/";


	//alert($.fn.jquery);

	$("#idBtnBuscarConvenio").click(function(){
		//alert('vamos a ver si esta oprando esta funcion');
		
		
		var cAno 		= $("#idAnosFiscales option:selected").text();
		var cPrograma 	= $("#idProgramasFederales option:selected").text();
		var cComponente = $("#idComponentesFederales option:selected").text();
		var cIncentivo	= $("#idIncentivosFederales option:selected").text();
		var cTipo 		= $("#idTipoPersona option:selected").text();
		var cCesionado	= $("#idCesionado option:selected").text();
		/*
		
		if  (!(cAno && cPrograma && cComponente && cTipo && cCesionado)) {
			alert('Llenar la información Requerida');
			return;
		}
		*/


		var datos = { 'ano': cAno , '¨programa':cPrograma , 'componente':cComponente , 'incentivo':cIncentivo, 'tipo' : cTipo, 'cesionado':cCesionado};

			$.ajax({
					type: 'POST',
					url: baseUrlCortaCorta+ "/plantillas/buscar_convenio",
					data:datos,
					success: function(Resp_Ok){
						//document.getElementById(ColumnaStatusMuestra).innerHTML = "EN PROCESO";
						//cAlerta = '<div class="alert alert-success" role="alert">' + 'Id [' +cIdMuestra+'] Inicio Etapa de Analisis' + '</div>';
						//document.getElementById('msg_alert_full').innerHTML = cAlerta;					
					}
				}) // FIN DEL AJAX---!


			/*
			$.ajax({
		      type: 'POST',
		      url: "baseUrlCortaCorta/buscar_convenio",
		      async: true,
		      cache: false,
		      crossDomain: true,
		      contentType: 'application/json; charset=utf-8',
		      dataType: 'json'
		    })
		    .fail(function(jqXHR, textStatus, errorThrown) {
		      console.log('ERROR: ' + errorThrown);
		    })
		    .always(function() {
		      // Do stuff
		    });
		    */

	}); //FIN DE LA FUNCION idBuscarConvenio
	/***********************************************************/

	
		
	// ocultar columna de una tabla    
    //$("#tablaDetalleMuestras tr").find('th:eq(6)').addClass("hidden");
    //$("#tablaDetalleMuestras tr").find('th:eq(7)').addClass("hidden");
    
    	
	
	 
	
	 

}); 