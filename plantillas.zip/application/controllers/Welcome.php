<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{

		$data = new stdClass();
		$data->title = 'Sistema de Plantillas SISEP';
		
		$data->contenido = 'v_pantalla_inicial'; //vista informe de resultados del estudios

		
		//$query = $this->db->query('select * from programasfederales')->result();

		$this->load->helper('dropdown');
		//function listData($table,$name,$value,$orderBy=null, $where_nombre_campo=null, $where_variable=null) {
		$data->AnosFiscalesCombo = listData('anosfiscales','nombreAnoFiscal', 'idAnoFiscal',null,null,null);
		$data->ProgramasFederalesCombo = listData('programasFederales','nombreProgramaFederal', 'idProgramaFederal',null,null,null);
		$data->ComponentesFederalesCombo = listData('componentesFederales','nombreComponenteFederal', 'idComponenteFederal',null,null,null);
		$data->IncentivosFederalesCombo = listData('incentivosFederales','nombreIncentivoFederal', 'idIncentivoFederal',null,null,null);

		


																		

		/*
		$data->menu_activo = 'servicios';
		$data->accion = 'ALTA';
		$data->panel_title = 'Informe de Resultados';
		$data->area_estudio = $cAreaEstudio;
		*/			
			
		
		//$this->load->view('welcome_message');
		$this->load->view('plantillas/encabezado',$data);
		//$this->load->view($data->contenido,$data);
		$this->load->view('v_pantalla_inicial',$data);
		//$this->load->view('plantillas/menu');
		$this->load->view('plantillas/piedepagina',$data);



		//$this->load->view('pruebas/prueba_ckeditor');
	}

	public function prueba(){

	}
}
