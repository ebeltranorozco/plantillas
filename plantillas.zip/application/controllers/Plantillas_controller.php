<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class plantillas_controller extends CI_Controller {

	public function buscar() { // es ajax 

		echo 'saliendo';
	}


	public function prueba() { // es ajax 

		echo 'saliendo de controlador (prueba)';
	}
}