<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
ERROR - 2017-09-25 14:07:47 --> Severity: Notice --> Undefined variable: panel_title C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 19
ERROR - 2017-09-25 14:07:47 --> Severity: Error --> Call to undefined function validation_errors() C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 23
ERROR - 2017-09-25 14:08:27 --> Severity: Error --> Call to undefined function validation_errors() C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 23
ERROR - 2017-09-25 14:09:24 --> Severity: Notice --> Undefined variable: cAno C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 32
ERROR - 2017-09-25 14:26:40 --> Severity: Notice --> Undefined variable: ProgramasFederalesCombo C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 39
ERROR - 2017-09-25 14:27:59 --> Severity: Notice --> Undefined variable: ProgramasFederalesCombo C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 39
ERROR - 2017-09-25 14:28:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 14
ERROR - 2017-09-25 14:28:26 --> Severity: Notice --> Undefined variable: ProgramasFederalesCombo C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 41
ERROR - 2017-09-25 22:31:21 --> Query error: Unknown column 'nombreProgramasFederales' in 'field list' - Invalid query: SELECT `nombreProgramasFederales`, `idProgramasFederales`
FROM `programasfederales`
ERROR - 2017-09-25 14:33:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 14
ERROR - 2017-09-25 14:33:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 14
ERROR - 2017-09-25 22:38:58 --> Query error: Table 'plantillas.insumosfederales' doesn't exist - Invalid query: SELECT `nombreInsumpFederal`, `idInsumoFederal`
FROM `insumosfederales`
ERROR - 2017-09-25 22:39:47 --> Query error: Table 'plantillas.insumosfederales' doesn't exist - Invalid query: SELECT `nombreInsumpFederal`, `idInsumoFederal`
FROM `insumosfederales`
ERROR - 2017-09-25 22:40:50 --> Query error: Table 'plantillas.insumosfederales' doesn't exist - Invalid query: SELECT `nombreInsumoFederal`, `idInsumoFederal`
FROM `insumosfederales`
ERROR - 2017-09-25 22:41:08 --> Query error: Table 'plantillas.insumosfederales' doesn't exist - Invalid query: SELECT `nombreInsumoFederal`, `idInsumoFederal`
FROM `insumosFederales`
ERROR - 2017-09-25 14:42:01 --> Severity: Notice --> Undefined variable: InsumosFederalesCombo C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 51
ERROR - 2017-09-25 14:42:34 --> Severity: Notice --> Undefined variable: InsumosFederalesCombo C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 51
ERROR - 2017-09-25 14:46:05 --> Severity: Notice --> Undefined variable: AnosFiscalesCombo C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 33
ERROR - 2017-09-25 15:02:38 --> Severity: Notice --> Undefined variable: options C:\xampp\htdocs\plantillas\application\views\v_pantalla_inicial.php 9
