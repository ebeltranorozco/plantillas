<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-27 22:37:06 --> 404 Page Not Found: Indexphp/plantillas_controller
