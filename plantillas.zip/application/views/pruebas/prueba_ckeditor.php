<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>A Simple Page with CKEditor</title>
        <!-- Make sure the path to CKEditor is correct. -->
        <!--<script src="../ckeditor.js"></script>-->
        
        <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
        <script type="text/javascript">
			function insertIntoCkeditor(){
				var str = document.getElementById('string').value;
				CKEDITOR.instances['editor1'].insertText(str);
			}
		</script>
    </head>
    <body>

    	<input type="text" id="string" placeholder="Please enter your string here" style="width: 209px; height: 21px">
		<input type="button" onclick="insertIntoCkeditor()" value="Insert" class="c_pointer">

        <form>
            <textarea name="editor1" id="editor1" rows="10" cols="80">
                This is my textarea to be replaced with CKEditor
            </textarea>
            <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'editor1', {
   				 	language: 'es',
    				uiColor: '#9AB8F3'
    			});
            </script>


        </form>
    </body>
</html>