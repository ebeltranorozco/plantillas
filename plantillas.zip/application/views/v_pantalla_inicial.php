
<?php  

$cAno = array('name'=>'ano_fiscal','id'=>'ano_fiscal','class'=>'form-control', 'value'=>set_value('ano_fiscal'));

$cTipoUser = array( 'F' => 'Fisica','M'=> 'Moral');
$cUserCesionado = array( 'S'=>'Si', 'N'=> 'No');
/*
$cPrograma = array('name'=>'programa_federal','id'=>'programa_federal','class'=>'form-control' ,'value' => set_value('programa_federal'));
$cComponente = array('name'=>'componente_fiscal','id'=>'componente_fiscal','class'=>'form-control','value'=>set_value('componente_fiscal'));
$cIncentivo= array('name'=>'incentivo_fiscal','id'=>'incentivo_fiscal','class'=>'form-control' ,'value' => set_value('incentivo_fiscal'));
$cTipo	=array('name'=>'tipo_usuario','id'=>'tipo_usuario','class'=>'form-control' ,'value' => set_value('tipo_usuario'));
$cCesionado = array('name'=>'cesionado_beneficiario','id'=>'cesionado_beneficiario','class'=>'form-control' ,'value' => set_value('cesionado_beneficiario'));
*/
//var_dump($ProgramasFederalesCombo);
?>	


<div class = "container" >
	<div class="panel panel-primary">

		<div class="panel-heading">
			<h3 class="panel-title" id='panel-encabezado'>Pantalla Inicial</h3>
		</div> <!--fin panel heading -->

		<div class="panel-body">
			<?php if (validation_errors()) { ?> 
				<div class="alert alert-danger" role="alert"><?php echo validation_errors(); ?> </div>
			<?php } ?>

			<form method="POST" > 

				<div class="row">
					<div class="form-group col-xs-6 col-sm-3">
						<?php echo form_label('Año:'); ?>
						<?php echo form_dropdown('idAnosFiscales',$AnosFiscalesCombo,$selected = 1,'class="form-control" id="idAnosFiscales"'); ?>
					</div>
				</div><!-- fin del row-->



				<div class="row">
					<div class="form-group col-xs-6 col-sm-6">
						<?php echo form_label('Programa Federal:'); ?>
						<?php echo form_dropdown('idProgramasFederales',$ProgramasFederalesCombo,$selected = 1,'class="form-control" id="idProgramasFederales"'); ?>						
					</div>
				</div>

				<div class="row">
					<div class="form-group col-xs-6 col-sm-6">
						<?php echo form_label('Componente Federal:'); ?>
						<?php echo form_dropdown('idComponentesFederales',$ComponentesFederalesCombo,$selected = 1,'class="form-control" id="idComponentesFederales"'); ?>						
					</div>
				</div>

				<div class="row">
					<div class="form-group col-xs-6 col-sm-6">
						<?php echo form_label('Incentivo Federal:'); ?>
						<?php echo form_dropdown('idIncentivosFederales',$IncentivosFederalesCombo,$selected = 1,'class="form-control" id="idIncentivosFederales"'); ?>
					</div>
				</div>

				<div class="row">
					<div class="form-group col-xs-6 col-sm-6">
						<?php echo form_label('Tipo de Persona:'); ?>
						<?php echo form_dropdown('idTipoUsuario', $cTipoUser, 'Fisica','class=form-control id=idTipoPersona'); ?>
					</div>
				</div>

				<div class="row">
					<div class="form-group col-xs-6 col-sm-6">
						<?php echo form_label('Beneficiario Cesionado:'); ?>
						<?php echo form_dropdown('idTipoUsuario', $cUserCesionado, 'Fisica','class=form-control id=idCesionado'); ?>					
					</div>
				</div>

				<div class="row">
					<div class="form-group col-xs-6 col-sm-6">						
						<button id="idBtnBuscarConvenio" type="button" class="btn btn-primary">Buscar Convenio</button>						
					</div>
				</div>


			</form> <!-- fin del form -->
		</div> <!-- fin del div panel-bodu -->
	</div> <!-- fin del panel-primary -->
</div> <!-- fin del container -->


<textarea cols='80' id='editor1' name='editor1' rows='10'>
</textarea>
<script type='text/javascript'>
	//CKEDITOR.replace ('editor1');
</script>
