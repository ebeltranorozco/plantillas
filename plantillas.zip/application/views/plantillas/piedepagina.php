<?php

defined('BASEPATH') OR exit('No direct script access allowed');

?>

<!-- CARGANDO JQUERY SEP 17 -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>

<script src="<?php echo base_url('assets/jquery/jquery-3.1.0.min.js')?>"></script>-->

<!-- CARGANDO BOOTSTRAP SEP 17 -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->   



 
    <!--  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/__jquery.tablesorter/jquery.tablesorter.min.js"></script>   -->


    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <!--     <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>   -->
	<!-- incluidos para las tablas perrona de los crud --> 
  <!--
    <script src="<?php echo base_url('assets/datatables/js/jquery.dataTables.min.js')?>"></script>
  	<script src="<?php echo base_url('assets/datatables/js/dataTables.bootstrap.js')?>"></script>
-->
	

  		
<!--
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jszip-3.1.3/pdfmake-0.1.27/dt-1.10.15/b-1.3.1/b-html5-1.3.1/b-print-1.3.1/r-2.1.1/sc-1.4.2/datatables.min.css"/>

 		<script type="text/javascript" src="https://cdn.datatables.net/v/dt/jszip-3.1.3/pdfmake-0.1.27/dt-1.10.15/b-1.3.1/b-html5-1.3.1/b-print-1.3.1/r-2.1.1/sc-1.4.2/datatables.min.js"></script>
--> 
  		<!--<script type="text/javascript" src="//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"></script>-->

    
  
    <script src="<?php echo base_url(); ?>assets/js/funciones.js" type="text/javascript"></script>
  
  </body>

</html>